package app.simmer.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface RecipeDao {
    @Query("SELECT * FROM recipes ORDER BY createdAt DESC")
    fun all(): Flow<List<Recipe>>

    @Query("SELECT * FROM recipes WHERE id = :id")
    suspend fun byId(id: Long): Recipe?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(recipe: Recipe): Long

    @Query("DELETE FROM recipes WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface GroceryDao {
    @Query("SELECT * FROM grocery ORDER BY createdAt ASC")
    fun all(): Flow<List<GroceryItem>>

    @Query("SELECT * FROM grocery WHERE recipeId = :recipeId")
    suspend fun forRecipe(recipeId: Long): List<GroceryItem>

    @Insert
    suspend fun insertAll(items: List<GroceryItem>)

    @Update
    suspend fun update(item: GroceryItem)

    @Delete
    suspend fun delete(item: GroceryItem)

    @Query("DELETE FROM grocery WHERE done = 1")
    suspend fun clearDone()

    @Query("DELETE FROM grocery")
    suspend fun clearAll()
}

@Database(entities = [Recipe::class, GroceryItem::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun recipeDao(): RecipeDao
    abstract fun groceryDao(): GroceryDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "simmer.db")
                .fallbackToDestructiveMigration()
                .build()
                .also { instance = it }
        }
    }
}
