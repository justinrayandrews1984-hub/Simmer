package app.simmer.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import app.simmer.data.Recipe

/**
 * Two stages: paste a link and import, then review the fields and save.
 * When [existing] is given, we skip straight to the form to edit it.
 */
@Composable
fun AddRecipeScreen(
    existing: Recipe?,
    sharedUrl: String,
    knownCategories: List<String>,
    onImport: (String, (Result<Recipe>) -> Unit) -> Unit,
    onSave: (Recipe) -> Unit,
    onCancel: () -> Unit,
) {
    var draft by remember { mutableStateOf(existing) }
    var url by rememberSaveable { mutableStateOf(sharedUrl) }
    var importing by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }

    fun runImport() {
        if (url.isBlank() || importing) return
        importing = true; error = null; info = null
        onImport(url) { result ->
            importing = false
            result.onSuccess { r ->
                draft = r
                info = "Found ${r.ingredients.size} ingredients and ${r.steps.size} steps. Check them over, then save."
            }.onFailure { e ->
                error = e.message ?: "Couldn't import that page."
            }
        }
    }

    // A link shared from the browser starts importing on its own.
    LaunchedEffect(sharedUrl) {
        if (sharedUrl.isNotBlank() && existing == null && draft == null) runImport()
    }

    val d = draft
    if (d == null) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                "Paste a link to a recipe page. Simmer downloads it and keeps the recipe as text, so it stays even if the site changes.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedTextField(
                value = url,
                onValueChange = { url = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Recipe link") },
                placeholder = { Text("https://…") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            )
            Button(onClick = { runImport() }, enabled = !importing && url.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                if (importing) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                    Spacer(Modifier.width(10.dp))
                    Text("Fetching recipe…")
                } else Text("Import recipe")
            }
            val err = error
            if (err != null) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Text(err, Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onErrorContainer)
                }
            }
            OutlinedButton(onClick = { draft = Recipe(source = url.trim()) }, modifier = Modifier.fillMaxWidth()) {
                Text("Or type it in by hand")
            }
            Text(
                "Tip: in Chrome, tap Share on a recipe page and pick Simmer. It imports right away.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    } else {
        RecipeForm(
            initial = d,
            info = info,
            knownCategories = knownCategories,
            onSave = onSave,
            onCancel = { if (existing != null) onCancel() else { draft = null; info = null } },
        )
    }
}

@Composable
private fun RecipeForm(
    initial: Recipe,
    info: String?,
    knownCategories: List<String>,
    onSave: (Recipe) -> Unit,
    onCancel: () -> Unit,
) {
    var title by remember(initial) { mutableStateOf(initial.title) }
    var category by remember(initial) { mutableStateOf(initial.category) }
    var servings by remember(initial) { mutableStateOf(initial.servings) }
    var time by remember(initial) { mutableStateOf(initial.time) }
    var source by remember(initial) { mutableStateOf(initial.source) }
    var ingredients by remember(initial) { mutableStateOf(initial.ingredients.joinToString("\n")) }
    var steps by remember(initial) { mutableStateOf(initial.steps.joinToString("\n")) }
    var notes by remember(initial) { mutableStateOf(initial.notes) }

    val suggestions = remember(knownCategories) {
        (listOf("Dinner", "Lunch", "Breakfast", "Baking", "Soup", "Dessert", "Snacks", "Drinks") + knownCategories).distinct()
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (info != null) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Text(info, Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onPrimaryContainer)
            }
        }
        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            androidx.compose.foundation.lazy.items(suggestions) { c ->
                androidx.compose.material3.SuggestionChip(onClick = { category = c }, label = { Text(c) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = servings, onValueChange = { servings = it }, label = { Text("Servings") }, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(value = time, onValueChange = { time = it }, label = { Text("Time") }, singleLine = true, modifier = Modifier.weight(1f))
        }
        OutlinedTextField(value = source, onValueChange = { source = it }, label = { Text("Source link") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(
            value = ingredients, onValueChange = { ingredients = it },
            label = { Text("Ingredients (one per line)") }, minLines = 5, modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = steps, onValueChange = { steps = it },
            label = { Text("Steps (one per line)") }, minLines = 6, modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = notes, onValueChange = { notes = it },
            label = { Text("Notes") }, minLines = 2, modifier = Modifier.fillMaxWidth(),
        )
        Button(
            onClick = {
                fun lines(s: String) = s.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
                onSave(
                    initial.copy(
                        title = title.trim().ifBlank { "Untitled recipe" },
                        category = category.trim(),
                        servings = servings.trim(),
                        time = time.trim(),
                        source = source.trim(),
                        ingredients = lines(ingredients),
                        steps = lines(steps),
                        notes = notes.trim(),
                    )
                )
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Save recipe") }
        OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("Cancel") }
        Spacer(Modifier.height(24.dp))
    }
}
