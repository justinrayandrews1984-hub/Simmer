package app.simmer.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Light = lightColorScheme(
    primary = Color(0xFF2E7A56),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE3F1E8),
    onPrimaryContainer = Color(0xFF123B27),
    secondary = Color(0xFF5F685F),
    background = Color(0xFFF6F7F4),
    onBackground = Color(0xFF1B1F1C),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1B1F1C),
    surfaceVariant = Color(0xFFEEF1EC),
    onSurfaceVariant = Color(0xFF5F685F),
    outline = Color(0xFFC9D0C8),
    error = Color(0xFFB4542A),
)

private val Dark = darkColorScheme(
    primary = Color(0xFF5FC08E),
    onPrimary = Color(0xFF0F1A13),
    primaryContainer = Color(0xFF1F3328),
    onPrimaryContainer = Color(0xFFCDEBD9),
    secondary = Color(0xFF9AA49B),
    background = Color(0xFF141715),
    onBackground = Color(0xFFEEF1EC),
    surface = Color(0xFF1E2320),
    onSurface = Color(0xFFEEF1EC),
    surfaceVariant = Color(0xFF262C28),
    onSurfaceVariant = Color(0xFF9AA49B),
    outline = Color(0xFF3B443E),
    error = Color(0xFFE4855A),
)

@Composable
fun SimmerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        content = content,
    )
}
