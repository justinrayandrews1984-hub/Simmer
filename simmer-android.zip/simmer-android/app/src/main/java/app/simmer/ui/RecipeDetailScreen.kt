package app.simmer.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import app.simmer.data.Recipe

@Composable
fun RecipeDetailScreen(
    recipe: Recipe,
    onAddToGrocery: () -> Unit,
    onToggleFavorite: () -> Unit,
    onDelete: () -> Unit,
) {
    val context = LocalContext.current
    val checked = remember(recipe.id) { mutableStateOf(setOf<Int>()) }
    var confirmDelete by remember { mutableStateOf(false) }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete “${recipe.title}”?") },
            text = { Text("This can't be undone.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Keep") } },
        )
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 32.dp),
    ) {
        item {
            Text(recipe.title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
            val meta = buildList {
                if (recipe.category.isNotBlank()) add(recipe.category)
                if (recipe.servings.isNotBlank()) add("Serves ${recipe.servings}")
                if (recipe.time.isNotBlank()) add(recipe.time)
            }
            if (meta.isNotEmpty()) {
                Text(meta.joinToString("  ·  "), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (recipe.source.isNotBlank()) {
                TextButton(
                    onClick = {
                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(recipe.source))) }
                    },
                    contentPadding = PaddingValues(0.dp),
                ) { Text("Open original page") }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onAddToGrocery) { Text("Add to grocery list") }
                OutlinedButton(onClick = onToggleFavorite) {
                    androidx.compose.material3.Icon(
                        if (recipe.favorite) Icons.Default.Star else Icons.Outlined.StarBorder,
                        contentDescription = null,
                        Modifier.width(18.dp),
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(if (recipe.favorite) "Favourited" else "Favourite")
                }
            }
            SectionHeading("Ingredients")
        }
        if (recipe.ingredients.isEmpty()) item { Text("None listed", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        itemsIndexed(recipe.ingredients) { i, ing ->
            val done = i in checked.value
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Checkbox(checked = done, onCheckedChange = { checked.value = if (done) checked.value - i else checked.value + i })
                Text(
                    ing,
                    textDecoration = if (done) TextDecoration.LineThrough else null,
                    color = if (done) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onBackground,
                )
            }
        }
        item { SectionHeading("Steps") }
        if (recipe.steps.isEmpty()) item { Text("None listed", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        itemsIndexed(recipe.steps) { i, step ->
            Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "${i + 1}",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.width(28.dp),
                )
                Text(step, modifier = Modifier.weight(1f))
            }
        }
        if (recipe.notes.isNotBlank()) {
            item {
                SectionHeading("Notes")
                Text(recipe.notes)
            }
        }
        item {
            Spacer(Modifier.height(32.dp))
            TextButton(onClick = { confirmDelete = true }) {
                Text("Delete recipe", color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
fun SectionHeading(text: String) {
    Text(
        text.uppercase(),
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 24.dp, bottom = 8.dp),
    )
}
