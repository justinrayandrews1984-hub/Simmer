package app.simmer

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.simmer.importer.RecipeImporter
import app.simmer.ui.AddRecipeScreen
import app.simmer.ui.GroceryScreen
import app.simmer.ui.RecipeDetailScreen
import app.simmer.ui.RecipeListScreen
import app.simmer.ui.SimmerTheme

sealed class Screen {
    data object Recipes : Screen()
    data class Detail(val id: Long) : Screen()
    data class Add(val editId: Long? = null, val sharedUrl: String = "") : Screen()
    data object Grocery : Screen()
}

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    // Set when a link is shared into the app from the browser.
    private var pendingUrl by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        pendingUrl = urlFrom(intent)
        setContent {
            SimmerTheme {
                SimmerApp(vm = vm, sharedUrl = pendingUrl, onSharedUrlConsumed = { pendingUrl = null })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        urlFrom(intent)?.let { pendingUrl = it }
    }

    private fun urlFrom(intent: Intent?): String? {
        if (intent?.action != Intent.ACTION_SEND) return null
        return RecipeImporter.extractUrl(intent.getStringExtra(Intent.EXTRA_TEXT))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimmerApp(vm: AppViewModel, sharedUrl: String?, onSharedUrlConsumed: () -> Unit) {
    val context = LocalContext.current
    val recipes by vm.recipes.collectAsStateWithLifecycle()
    val grocery by vm.grocery.collectAsStateWithLifecycle()
    var screen by remember { mutableStateOf<Screen>(Screen.Recipes) }

    // A shared link jumps straight to the import screen.
    LaunchedEffect(sharedUrl) {
        if (sharedUrl != null) {
            screen = Screen.Add(sharedUrl = sharedUrl)
            onSharedUrlConsumed()
        }
    }

    val current = screen
    BackHandler(enabled = current !is Screen.Recipes) {
        screen = when (current) {
            is Screen.Add -> current.editId?.let { Screen.Detail(it) } ?: Screen.Recipes
            else -> Screen.Recipes
        }
    }

    val title = when (current) {
        Screen.Recipes -> if (recipes.isEmpty()) "Simmer" else "Simmer  ·  ${recipes.size}"
        is Screen.Detail -> "Recipe"
        is Screen.Add -> if (current.editId != null) "Edit recipe" else "Add a recipe"
        Screen.Grocery -> "Grocery list"
    }
    val detailRecipe = (current as? Screen.Detail)?.let { d -> recipes.firstOrNull { it.id == d.id } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, fontWeight = FontWeight.Black) },
                navigationIcon = {
                    if (current !is Screen.Recipes && current !is Screen.Grocery) {
                        IconButton(onClick = { screen = Screen.Recipes }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                actions = {
                    if (detailRecipe != null) {
                        IconButton(onClick = { screen = Screen.Add(editId = detailRecipe.id) }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = current is Screen.Recipes || current is Screen.Detail,
                    onClick = { screen = Screen.Recipes },
                    icon = { Icon(Icons.Default.MenuBook, contentDescription = null) },
                    label = { Text("Recipes") },
                )
                NavigationBarItem(
                    selected = current is Screen.Add && current.editId == null,
                    onClick = { screen = Screen.Add() },
                    icon = { Icon(Icons.Default.AddCircle, contentDescription = null) },
                    label = { Text("Add") },
                )
                NavigationBarItem(
                    selected = current is Screen.Grocery,
                    onClick = { screen = Screen.Grocery },
                    icon = { Icon(Icons.Default.ShoppingCart, contentDescription = null) },
                    label = { Text("Grocery") },
                )
            }
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (current) {
                Screen.Recipes -> RecipeListScreen(
                    recipes = recipes,
                    onOpen = { screen = Screen.Detail(it.id) },
                    onToggleFavorite = { vm.toggleFavorite(it) },
                    onAdd = { screen = Screen.Add() },
                )
                is Screen.Detail -> {
                    if (detailRecipe != null) {
                        RecipeDetailScreen(
                            recipe = detailRecipe,
                            onAddToGrocery = {
                                vm.addRecipeToGrocery(detailRecipe)
                                Toast.makeText(context, "Added to grocery list", Toast.LENGTH_SHORT).show()
                            },
                            onToggleFavorite = { vm.toggleFavorite(detailRecipe) },
                            onDelete = { vm.deleteRecipe(detailRecipe.id); screen = Screen.Recipes },
                        )
                    }
                }
                is Screen.Add -> {
                    val editing = current.editId?.let { id -> recipes.firstOrNull { it.id == id } }
                    key(current) { AddRecipeScreen(
                        existing = editing,
                        sharedUrl = current.sharedUrl,
                        knownCategories = recipes.map { it.category }.filter { it.isNotBlank() }.distinct().sorted(),
                        onImport = { url, cb -> vm.importFromUrl(url, cb) },
                        onSave = { r ->
                            vm.saveRecipe(r) { id ->
                                Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show()
                                screen = Screen.Detail(id)
                            }
                        },
                        onCancel = { screen = current.editId?.let { Screen.Detail(it) } ?: Screen.Recipes },
                    ) }
                }
                Screen.Grocery -> GroceryScreen(
                    items = grocery,
                    recipes = recipes,
                    onAdd = { vm.addGroceryItem(it) },
                    onToggle = { vm.toggleGrocery(it) },
                    onRemove = { vm.removeGrocery(it) },
                    onClearDone = { vm.clearDoneGrocery() },
                    onClearAll = { vm.clearAllGrocery() },
                    onPlan = { ids ->
                        vm.addRecipesToGrocery(ids)
                        Toast.makeText(context, "Added ${ids.size} recipe${if (ids.size == 1) "" else "s"}", Toast.LENGTH_SHORT).show()
                    },
                )
            }
        }
    }
}
