package app.simmer.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.simmer.data.Recipe

enum class SortMode(val label: String) { NEWEST("Newest"), OLDEST("Oldest"), AZ("A to Z"), CATEGORY("Category") }

@Composable
fun RecipeListScreen(
    recipes: List<Recipe>,
    onOpen: (Recipe) -> Unit,
    onToggleFavorite: (Recipe) -> Unit,
    onAdd: () -> Unit,
) {
    var query by rememberSaveable { mutableStateOf("") }
    var sort by rememberSaveable { mutableStateOf(SortMode.NEWEST) }
    var category by rememberSaveable { mutableStateOf("") } // "" = all, "★" = favourites
    var sortMenu by remember { mutableStateOf(false) }

    val categories = remember(recipes) { recipes.map { it.category }.filter { it.isNotBlank() }.distinct().sorted() }

    val shown = remember(recipes, query, sort, category) {
        val q = query.trim().lowercase()
        recipes.asSequence()
            .filter {
                when (category) {
                    "" -> true
                    "★" -> it.favorite
                    else -> it.category == category
                }
            }
            .filter { r ->
                q.isEmpty() || listOf(r.title, r.category, r.notes, r.ingredients.joinToString(" "))
                    .joinToString(" ").lowercase().contains(q)
            }
            .sortedWith(
                when (sort) {
                    SortMode.NEWEST -> compareByDescending<Recipe> { it.createdAt }
                    SortMode.OLDEST -> compareBy<Recipe> { it.createdAt }
                    SortMode.AZ -> compareBy<Recipe, String>(String.CASE_INSENSITIVE_ORDER) { it.title }
                    SortMode.CATEGORY -> compareBy<Recipe, String>(String.CASE_INSENSITIVE_ORDER) { it.category.ifBlank { "zzz" } }
                        .thenBy<Recipe, String>(String.CASE_INSENSITIVE_ORDER) { it.title }
                }
            )
            .toList()
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Search recipes or ingredients") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
            )
            Column {
                TextButton(onClick = { sortMenu = true }) { Text(sort.label) }
                DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                    SortMode.entries.forEach { mode ->
                        DropdownMenuItem(text = { Text(mode.label) }, onClick = { sort = mode; sortMenu = false })
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 4.dp)) {
            item {
                FilterChip(selected = category == "", onClick = { category = "" }, label = { Text("All") })
            }
            items(categories) { c ->
                FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c) })
            }
            item {
                FilterChip(
                    selected = category == "★",
                    onClick = { category = "★" },
                    label = { Text("Favourites") },
                    leadingIcon = { Icon(Icons.Default.Star, contentDescription = null, Modifier.width(16.dp)) },
                )
            }
        }
        Spacer(Modifier.height(8.dp))

        if (recipes.isEmpty()) {
            EmptyState(
                title = "No recipes yet",
                body = "Paste a link from any recipe site and Simmer saves the recipe as text, so it's yours even if the site goes away.",
                action = "Add your first recipe",
                onAction = onAdd,
            )
        } else if (shown.isEmpty()) {
            EmptyState(title = "Nothing matches", body = "Try a different search or category.")
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
            ) {
                items(shown, key = { it.id }) { r ->
                    RecipeCard(r, onClick = { onOpen(r) }, onToggleFavorite = { onToggleFavorite(r) })
                }
            }
        }
    }
}

@Composable
private fun RecipeCard(r: Recipe, onClick: () -> Unit, onToggleFavorite: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Row(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(r.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                val meta = buildList {
                    if (r.category.isNotBlank()) add(r.category)
                    if (r.time.isNotBlank()) add(r.time)
                    if (r.servings.isNotBlank()) add("Serves ${r.servings}")
                    add("${r.ingredients.size} ingredients")
                }
                Text(
                    meta.joinToString("  ·  "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            IconButton(onClick = onToggleFavorite) {
                Icon(
                    if (r.favorite) Icons.Default.Star else Icons.Outlined.StarBorder,
                    contentDescription = "Favourite",
                    tint = if (r.favorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
fun EmptyState(title: String, body: String, action: String? = null, onAction: () -> Unit = {}) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 48.dp, horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(body, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (action != null) {
            Spacer(Modifier.height(16.dp))
            androidx.compose.material3.Button(onClick = onAction) { Text(action) }
        }
    }
}
