package app.simmer.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import app.simmer.data.GroceryItem
import app.simmer.data.Recipe

@Composable
fun GroceryScreen(
    items: List<GroceryItem>,
    recipes: List<Recipe>,
    onAdd: (String) -> Unit,
    onToggle: (GroceryItem) -> Unit,
    onRemove: (GroceryItem) -> Unit,
    onClearDone: () -> Unit,
    onClearAll: () -> Unit,
    onPlan: (Set<Long>) -> Unit,
) {
    var newItem by remember { mutableStateOf("") }
    var planning by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }

    if (planning) {
        PlanDialog(recipes, onDismiss = { planning = false }, onConfirm = { onPlan(it); planning = false })
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear the whole list?") },
            confirmButton = { TextButton(onClick = { confirmClear = false; onClearAll() }) { Text("Clear it") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Keep it") } },
        )
    }

    val groups = remember(items) {
        items.groupBy { it.recipeTitle.ifBlank { "Other items" } }
            .toSortedMap(compareBy<String> { if (it == "Other items") 0 else 1 }.thenBy<String, String>(String.CASE_INSENSITIVE_ORDER) { it })
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = newItem,
                onValueChange = { newItem = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Add an item (milk, eggs…)") },
                singleLine = true,
            )
            Button(onClick = { onAdd(newItem); newItem = "" }, enabled = newItem.isNotBlank()) { Text("Add") }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { planning = true }) { Text("Plan from recipes") }
            OutlinedButton(onClick = onClearDone, enabled = items.any { it.done }) { Text("Clear checked") }
            TextButton(onClick = { confirmClear = true }, enabled = items.isNotEmpty()) {
                Text("Clear all", color = MaterialTheme.colorScheme.error)
            }
        }
        if (items.isEmpty()) {
            EmptyState(
                title = "List is empty",
                body = "Add items above, or open a recipe and tap “Add to grocery list”. “Plan from recipes” lets you pick several at once.",
            )
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                groups.forEach { (group, groupItems) ->
                    item(key = "h-$group") {
                        Row(
                            Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(group.uppercase(), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                "${groupItems.count { !it.done }}/${groupItems.size}",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    items(groupItems, key = { it.id }) { item ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = item.done, onCheckedChange = { onToggle(item) })
                            Text(
                                item.text,
                                modifier = Modifier.weight(1f),
                                textDecoration = if (item.done) TextDecoration.LineThrough else null,
                                color = if (item.done) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onBackground,
                            )
                            IconButton(onClick = { onRemove(item) }) {
                                Icon(Icons.Default.Close, contentDescription = "Remove", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlanDialog(recipes: List<Recipe>, onDismiss: () -> Unit, onConfirm: (Set<Long>) -> Unit) {
    var picked by remember { mutableStateOf(setOf<Long>()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("What are you cooking?", fontWeight = FontWeight.Bold) },
        text = {
            if (recipes.isEmpty()) {
                Text("No recipes saved yet.")
            } else {
                LazyColumn {
                    items(recipes.sortedBy { it.title.lowercase() }, key = { it.id }) { r ->
                        val on = r.id in picked
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = on, onCheckedChange = { picked = if (on) picked - r.id else picked + r.id })
                            Column {
                                Text(r.title)
                                if (r.category.isNotBlank()) {
                                    Text(r.category, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(picked) }, enabled = picked.isNotEmpty()) { Text("Add to list") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
